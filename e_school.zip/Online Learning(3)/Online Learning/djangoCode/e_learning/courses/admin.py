from django.contrib import admin

from courses.models import Lesson,  Standard, Subject, Comment, Reply

# Register your models here.
admin.site.register(Standard)
admin.site.register(Subject)
admin.site.register(Lesson)
admin.site.register(Comment)
admin.site.register(Reply)


