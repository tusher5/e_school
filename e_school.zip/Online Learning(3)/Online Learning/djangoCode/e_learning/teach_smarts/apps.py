from django.apps import AppConfig


class TeachSmartsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'teach_smarts'
